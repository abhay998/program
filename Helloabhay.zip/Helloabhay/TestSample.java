package Helloabhay;

public class TestSample extends Twodarray {

}
